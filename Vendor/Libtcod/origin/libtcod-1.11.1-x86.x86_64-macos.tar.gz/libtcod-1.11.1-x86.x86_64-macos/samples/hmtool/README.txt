libtcod height map tool

Actually this is currently more a curiosity than a real useful tool.
It allows you to tweak a heightmap by hand and generate the corresponding C,C++ or Python code.

The heightmap tool source code is public domain. Do whatever you want with it.

NB : this tool has not been upgraded to the latest libtcod API so the generated code won't compile.
